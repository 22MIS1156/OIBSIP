package financial.bank;

public enum Bank{
	BB,
	OTP,
	Erste,
	CIB,
	Raiffeisen,
	Citibank,
	FHB,
	MKB,
	Unicredit
}